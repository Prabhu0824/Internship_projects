import nltk
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import random
from google import genai
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Download necessary NLTK data (quietly)
try:
    nltk.data.find('tokenizers/punkt')
except LookupError:
    nltk.download('punkt', quiet=True)
try:
    nltk.data.find('tokenizers/punkt_tab')
except LookupError:
    nltk.download('punkt_tab', quiet=True)
try:
    nltk.data.find('corpora/wordnet')
except LookupError:
    nltk.download('wordnet', quiet=True)

from nltk.stem import WordNetLemmatizer

lemmatizer = WordNetLemmatizer()

# Configure Gemini
api_key = os.getenv("GEMINI_API_KEY")
if api_key:
    client = genai.Client(api_key=api_key)
    model_name = "models/gemini-2.5-flash"
else:
    print("Warning: GEMINI_API_KEY not found in .env. LLM fallback will not be available.")
    client = None

# Predefined FAQs/Intents
faqs = {
    "hello": ["Hello! How can I help you today?", "Hi there! What can I do for you?", "Greetings!"],
    "hi": ["Hello!", "Hi!", "Hey there!"],
    "how are you": ["I'm just a bot, but I'm doing great! How about you?", "I am functioning within normal parameters."],
    "what is your name": ["I am an AI Chatbot created to assist you.", "You can call me AI Assistant."],
    "help": ["I can answer your questions. Just ask me anything!", "I am here to help. What do you need assistance with?"],
    "bye": ["Goodbye! Have a great day!", "See you later!", "Bye!"]
}

# Simple corpus for similarity matching if no exact match
corpus = [
    "what services do you offer",
    "how can i contact support",
    "what are your opening hours",
    "where are you located",
    "pricing information"
]
responses = [
    "We offer a variety of AI services including chatbots and automation.",
    "You can contact support at support@example.com.",
    "We are open 24/7 online.",
    "We are a digital-first company located in the cloud.",
    "Our pricing is flexible. Please visit our pricing page for details."
]

def preprocess(text):
    tokens = nltk.word_tokenize(text.lower())
    return " ".join([lemmatizer.lemmatize(token) for token in tokens])

def get_llm_response(user_input):
    if not client:
        return "I'm sorry, I couldn't reach my brain (API key missing). Can you rephrase?"
    try:
        # Improved prompt for better effectiveness
        prompt = f"You are a helpful AI customer support assistant. Provide a concise and accurate answer to the following user question:\n\n{user_input}"
        response = client.models.generate_content(
            model=model_name,
            contents=[prompt] # Updated contents argument to be a list
        )
        return response.text
    except Exception as e:
        print(f"Error calling Gemini API: {e}")
        return "I'm sorry, I'm having trouble thinking right now. Can you try again later?"

def get_response(user_input):
    user_input_processed = preprocess(user_input)
    
    # Check for exact/keyword matches using basic intent keys
    for key in faqs:
        if key in user_input_processed:
            return random.choice(faqs[key])
            
    # Use TF-IDF for similarity matching with corpus
    tfidf_vectorizer = TfidfVectorizer()
    tfidf_matrix = tfidf_vectorizer.fit_transform(corpus + [user_input])
    similarity_scores = cosine_similarity(tfidf_matrix[-1], tfidf_matrix[:-1])
    
    # Get the index of the most similar question
    best_match_idx = similarity_scores.argsort()[0][-1]
    
    if similarity_scores[0][best_match_idx] > 0.4: # Increased threshold for "effectiveness"
        return responses[best_match_idx]
        
    # Fallback to LLM
    return get_llm_response(user_input)

def get_available_questions():
    """Returns a list of all predefined questions and FAQ keywords."""
    return list(faqs.keys()) + corpus
