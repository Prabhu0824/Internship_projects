from fastapi import FastAPI, Request, Form
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel
import uvicorn
import os
from contextlib import asynccontextmanager

from database import init_db, log_chat
from chatbot import get_response, get_available_questions

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup: Initialize database
    init_db()
    yield
    # Shutdown logic (if any) can go here

app = FastAPI(lifespan=lifespan)

# Create templates directory if it doesn't exist
if not os.path.exists("templates"):
    os.makedirs("templates")

templates = Jinja2Templates(directory="templates")

class ChatRequest(BaseModel):
    message: str

@app.get("/", response_class=HTMLResponse)
async def read_root(request: Request):
    questions = get_available_questions()
    return templates.TemplateResponse("index.html", {"request": request, "questions": questions})

@app.post("/chat")
async def chat_endpoint(chat_request: ChatRequest):
    user_message = chat_request.message
    bot_response = get_response(user_message)
    
    # Log to database
    log_chat(user_message, bot_response)
    
    return {"response": bot_response}

if __name__ == "__main__":
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=True)
