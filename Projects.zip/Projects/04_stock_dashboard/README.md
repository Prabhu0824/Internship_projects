# Project 04: Real-Time Stock Market Dashboard

A powerful, interactive financial dashboard built with Streamlit for tracking real-time market data across global indices and individual stocks.

## 🚀 Features
- **Real-Time Data**: Live fetching of stock and index data via Yahoo Finance (`yfinance`).
- **Interactive Charts**: Candlestick visualizations with zooming and technical indicator overlays.
- **Market Indicators**: Built-in toggle for 20-day and 50-day moving averages (MA).
- **Global Reach**: Supports global stock tickers (e.g., AAPL) and indices (e.g., Nifty 50 as `^NSEI`).
- **One-Click Select**: Quick buttons to switch between Nifty 50, S&P 500, and Nasdaq.

## 🛠️ Setup
1. **Install Deps**:
   - Standard: `pip install streamlit yfinance pandas plotly`
   - Windows Launcher: `py -m pip install streamlit yfinance pandas plotly`
2. **Run (Standard)**: `streamlit run app.py`
3. **Run (Windows Launcher)**: `py -m streamlit run app.py`

## 📂 Structure
- `app.py`: The main Streamlit application logic.
- `requirements.txt`: List of necessary Python libraries.
