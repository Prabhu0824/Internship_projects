import streamlit as st
import yfinance as yf
import pandas as pd
import plotly.graph_objects as go
from datetime import datetime, timedelta

# Page config
st.set_page_config(page_title="Real-Time Stock Dashboard", layout="wide")

# Title and Description
st.title("📈 Real-Time Stock Market Dashboard")
st.markdown("Monitor live stock data, visualize trends, and analyze financial indicators.")

# Sidebar for controls
st.sidebar.header("Customization")
ticker_input = st.sidebar.text_input("Enter Stock Ticker (e.g., AAPL, ^NSEI, TSLA)", value="^NSEI").upper()

# Optional: Add quick buttons for popular indices
st.sidebar.markdown("---")
st.sidebar.subheader("Quick Select")
if st.sidebar.button("Nifty 50"):
    ticker_input = "^NSEI"
if st.sidebar.button("S&P 500"):
    ticker_input = "^GSPC"
if st.sidebar.button("Nasdaq"):
    ticker_input = "^IXIC"

# Date range selection
st.sidebar.subheader("Time Range")
days_to_subtract = st.sidebar.slider("Number of days", min_value=1, max_value=365*2, value=30)
start_date = datetime.now() - timedelta(days=days_to_subtract)
end_date = datetime.now()

# Indicators selection
st.sidebar.subheader("Indicators")
show_ma20 = st.sidebar.checkbox("20-Day Moving Average", value=True)
show_ma50 = st.sidebar.checkbox("50-Day Moving Average", value=False)

# Fetch Data
@st.cache_data
def load_data(ticker, start, end):
    data = yf.download(ticker, start=start, end=end)
    return data

try:
    with st.spinner(f"Fetching data for {ticker_input}..."):
        df = load_data(ticker_input, start_date, end_date)

    if df.empty:
        st.error(f"No data found for ticker '{ticker_input}'. Please check the symbol and try again.")
    else:
        # Flatten MultiIndex columns if present (common in recent yfinance versions)
        if isinstance(df.columns, pd.MultiIndex):
            df.columns = df.columns.get_level_values(0)
        
        # Metrics section
        latest_price = df['Close'].iloc[-1].item()
        prev_price = df['Close'].iloc[-2].item()
        price_change = latest_price - prev_price
        pct_change = (price_change / prev_price) * 100

        col1, col2, col3 = st.columns(3)
        col1.metric("Latest Price", f"${latest_price:,.2f}", f"{price_change:+.2f} ({pct_change:+.2f}%)")
        col2.metric("Day High", f"${df['High'].iloc[-1].item():,.2f}")
        col3.metric("Day Low", f"${df['Low'].iloc[-1].item():,.2f}")

        # Plotly Chart
        fig = go.Figure()

        # Candlestick
        fig.add_trace(go.Candlestick(
            x=df.index,
            open=df['Open'],
            high=df['High'],
            low=df['Low'],
            close=df['Close'],
            name="Market Data"
        ))

        # Add Moving Averages
        if show_ma20:
            df['MA20'] = df['Close'].rolling(window=20).mean()
            fig.add_trace(go.Scatter(x=df.index, y=df['MA20'], line=dict(color='orange', width=2), name='MA20'))
        
        if show_ma50:
            df['MA50'] = df['Close'].rolling(window=50).mean()
            fig.add_trace(go.Scatter(x=df.index, y=df['MA50'], line=dict(color='blue', width=2), name='MA50'))

        fig.update_layout(
            title=f"{ticker_input} Stock Price Evolution",
            yaxis_title="Price (USD)",
            xaxis_rangeslider_visible=False,
            template="plotly_white",
            height=600
        )

        st.plotly_chart(fig, use_container_width=True)

        # Raw Data Section
        st.subheader("Recent Data Snippet")
        st.dataframe(df.tail(10).style.highlight_max(axis=0), use_container_width=True)

except Exception as e:
    st.error(f"An unexpected error occurred: {e}")

# Footer
st.markdown("---")
st.caption(f"Data provided by Yahoo Finance. Last updated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
