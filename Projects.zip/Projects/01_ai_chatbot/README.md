# Project 01: AI-Powered Chatbot

An intelligent customer support chatbot that uses custom NLP patterns for fast responses and falls back to a Google Gemini LLM for complex queries.

## 🚀 Features
- **Deterministic FAQ Response**: Uses NLTK and Cosine Similarity to find the best match in a predefined corpus.
- **LLM Fallback**: If no good match is found, the bot queries the Gemini API for a natural language response.
- **Modern UI**: A sleek, dark-themed chat interface built with HTML and CSS.
- **FastAPI Backend**: High-performance asynchronous API handling for real-time interaction.

## 🛠️ Setup
1. **API Key**: Create a `.env` file and add your `GEMINI_API_KEY`.
2. **Install Deps**:
   - Standard: `pip install -r requirements.txt`
   - Windows Launcher: `py -m pip install -r requirements.txt`
3. **Run (Standard)**: `python main.py`
4. **Run (Windows Launcher)**: `py main.py`

## 📂 Structure
- `main.py`: The FastAPI server.
- `chatbot.py`: Core logic for NLP and LLM integration.
- `database.py`: Handles FAQ storage and logging.
- `templates/`: Contains the frontend `index.html`.
