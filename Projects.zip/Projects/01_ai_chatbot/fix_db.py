import sqlite3

def fix_database():
    conn = sqlite3.connect('chat_logs.db')
    cursor = conn.cursor()
    
    # Check for session_id in chat_logs
    cursor.execute("PRAGMA table_info(chat_logs)")
    columns = [column[1] for column in cursor.fetchall()]
    
    if 'session_id' not in columns:
        print("Adding session_id column to chat_logs...")
        cursor.execute("ALTER TABLE chat_logs ADD COLUMN session_id TEXT")
    
    # Check if faqs table exists
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='faqs'")
    if not cursor.fetchone():
        print("Creating faqs table...")
        cursor.execute("""
            CREATE TABLE faqs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                question TEXT NOT NULL,
                answer TEXT NOT NULL
            )
        """)
    
    conn.commit()
    conn.close()
    print("Database fixed successfully.")

if __name__ == "__main__":
    fix_database()
