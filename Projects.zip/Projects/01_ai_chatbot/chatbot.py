import nltk
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import random
import requests
import os
from dotenv import load_dotenv
import re

# Load environment variables
load_dotenv()

# Download necessary NLTK data (quietly)
try:
    nltk.data.find('tokenizers/punkt')
except LookupError:
    nltk.download('punkt', quiet=True)
try:
    nltk.data.find('tokenizers/punkt_tab')
except LookupError:
    nltk.download('punkt_tab', quiet=True)
try:
    nltk.data.find('corpora/wordnet')
except LookupError:
    nltk.download('wordnet', quiet=True)

from nltk.stem import WordNetLemmatizer

lemmatizer = WordNetLemmatizer()

# Configure Groq
api_key = os.getenv("GROQ_API_KEY")
if not api_key:
    print("Warning: GROQ_API_KEY not found in .env. LLM fallback will be disabled.")

# Simple corpus for similarity matching if no exact match
corpus = [
    "how can i track my order",
    "where is my package",
    "what is your return policy",
    "how do i get a refund",
    "what services do you offer",
    "tell me about your plans",
    "how can i speak to a human",
    "where are you located",
    "do you offer international shipping"
]
responses = [
    "To track your order, please provide your Order ID (e.g., #12345).",
    "You can track your package using the link sent to your email or by providing your Order ID here.",
    "You can return any unused item within 30 days for a full refund. Shipping is on us!",
    "To request a refund, please send your order details to returns@example.com.",
    "We provide AI-powered customer support, automated data analysis, and custom bot development.",
    "We offer Basic, Pro, and Enterprise plans tailored to your business needs.",
    "I can transfer you to a live agent if you'd like. Would you like to wait for a representative?",
    "We are a digital-first company based in the cloud, with offices in San Francisco and London.",
    "Yes, we ship to over 50 countries worldwide!"
]

def preprocess(text):
    tokens = nltk.word_tokenize(text.lower())
    return " ".join([lemmatizer.lemmatize(token) for token in tokens])

def get_llm_response(user_input, history=None):
    if not api_key:
        return {"text": "I'm sorry, I couldn't reach my brain (API key missing). Can you rephrase or ask about predefined topics?"}
    
    try:
        messages = [{"role": "system", "content": "You are a professional AI customer support assistant. Be concise and helpful."}]
        
        # Add history to messages for contextual awareness
        if history:
            for log in reversed(history):
                messages.append({"role": "user", "content": log.user_message})
                messages.append({"role": "assistant", "content": log.bot_response})
        
        messages.append({"role": "user", "content": user_input})

        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_key}"
        }
        data = {
            "model": "llama-3.1-8b-instant",
            "messages": messages
        }
        response = requests.post("https://api.groq.com/openai/v1/chat/completions", headers=headers, json=data)
        response.raise_for_status()
        return {"text": response.json()["choices"][0]["message"]["content"]}
    except Exception as e:
        print(f"Error calling Groq API: {e}")
        return {"text": "I'm sorry, I'm having trouble thinking right now. Can you try again later?"}

def get_response(user_input, session_id=None):
    from database import get_all_faqs, get_chat_history
    
    user_input_processed = preprocess(user_input)
    
    # 1. Special logic for Order Tracking (Rich UI: Progress Bar)
    if "track" in user_input_processed and ("#" in user_input or any(char.isdigit() for char in user_input)):
        order_id_match = re.search(r'#?\d+', user_input)
        if order_id_match:
            order_id = order_id_match.group()
            status = random.choice(["Processing", "Shipped", "In Transit", "Delivered"])
            progress = {"Processing": 25, "Shipped": 50, "In Transit": 75, "Delivered": 100}[status]
            return {
                "text": f"Tracking status for Order {order_id}: **{status}**.",
                "type": "order_status",
                "data": {"status": status, "progress": progress, "order_id": order_id}
            }

    # 2. Check Database FAQs
    db_faqs = get_all_faqs()
    for faq in db_faqs:
        if re.search(r'\b' + re.escape(faq.question.lower()) + r'\b', user_input_processed):
            return {"text": faq.answer}
            
    # 3. TF-IDF for similarity matching with corpus
    tfidf_vectorizer = TfidfVectorizer()
    tfidf_matrix = tfidf_vectorizer.fit_transform(corpus + [user_input])
    similarity_scores = cosine_similarity(tfidf_matrix[-1], tfidf_matrix[:-1])
    best_match_idx = similarity_scores.argsort()[0][-1]
    
    if similarity_scores[0][best_match_idx] > 0.4:
        return {"text": responses[best_match_idx]}
        
    # 4. Fallback to LLM with history
    history = get_chat_history(session_id) if session_id else None
    return get_llm_response(user_input, history)

def get_available_questions():
    """Returns a curated list of sample questions for the UI."""
    return [
        "How can I track my order?",
        "What is your refund policy?",
        "Tell me about your pricing plans.",
        "What services do you offer?",
        "How do I contact support?",
        "Do you ship internationally?"
    ]
