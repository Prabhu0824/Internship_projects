from sqlalchemy import create_engine, Column, Integer, String, Text, DateTime
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from datetime import datetime

DATABASE_URL = "sqlite:///./chat_logs.db"

engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

class ChatLog(Base):
    __tablename__ = "chat_logs"

    id = Column(Integer, primary_key=True, index=True)
    session_id = Column(String, index=True, nullable=True)  # Added for memory
    user_message = Column(Text, nullable=False)
    bot_response = Column(Text, nullable=False)
    timestamp = Column(DateTime, default=datetime.utcnow)

class FAQ(Base):
    __tablename__ = "faqs"

    id = Column(Integer, primary_key=True, index=True)
    question = Column(String, nullable=False)
    answer = Column(Text, nullable=False)

def init_db():
    Base.metadata.create_all(bind=engine)

def log_chat(user_message: str, bot_response: str, session_id: str = None):
    db = SessionLocal()
    try:
        log_entry = ChatLog(user_message=user_message, bot_response=bot_response, session_id=session_id)
        db.add(log_entry)
        db.commit()
    finally:
        db.close()

def get_chat_history(session_id: str, limit: int = 5):
    db = SessionLocal()
    try:
        return db.query(ChatLog).filter(ChatLog.session_id == session_id).order_by(ChatLog.timestamp.desc()).limit(limit).all()
    finally:
        db.close()

def get_all_faqs():
    db = SessionLocal()
    try:
        return db.query(FAQ).all()
    finally:
        db.close()

def add_faq(question: str, answer: str):
    db = SessionLocal()
    try:
        new_faq = FAQ(question=question, answer=answer)
        db.add(new_faq)
        db.commit()
        return new_faq
    finally:
        db.close()

def delete_faq(faq_id: int):
    db = SessionLocal()
    try:
        db.query(FAQ).filter(FAQ.id == faq_id).delete()
        db.commit()
    finally:
        db.close()

def get_all_logs():
    db = SessionLocal()
    try:
        return db.query(ChatLog).order_by(ChatLog.timestamp.desc()).all()
    finally:
        db.close()

def clear_all_logs():
    db = SessionLocal()
    try:
        db.query(ChatLog).delete()
        db.commit()
    finally:
        db.close()
