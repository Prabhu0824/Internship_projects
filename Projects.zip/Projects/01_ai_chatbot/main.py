from fastapi import FastAPI, Request, Form, HTTPException
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel
import uvicorn
import os
from contextlib import asynccontextmanager
from typing import Optional

from database import init_db, log_chat, get_all_logs, clear_all_logs, add_faq, get_all_faqs, delete_faq
from chatbot import get_response, get_available_questions

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup: Initialize database
    init_db()
    # Seed initial FAQs if empty
    if not get_all_faqs():
        initial_faqs = [
            ("hello", "Hello! How can I help you today?"),
            ("refund", "Our refund policy allows for returns within 30 days of purchase."),
            ("pricing", "We have three plans: Basic ($10/mo), Pro ($30/mo), and Enterprise (Custom)."),
            ("contact", "You can contact our support team at support@example.com.")
        ]
        for q, a in initial_faqs:
            add_faq(q, a)
    yield

app = FastAPI(lifespan=lifespan)

# Create templates directory if it doesn't exist
if not os.path.exists("templates"):
    os.makedirs("templates")

templates = Jinja2Templates(directory="templates")

class ChatRequest(BaseModel):
    message: str
    session_id: Optional[str] = None

@app.get("/", response_class=HTMLResponse)
async def read_root(request: Request):
    questions = get_available_questions()
    return templates.TemplateResponse(
        request=request, name="index.html", context={"questions": questions}
    )

@app.post("/chat")
async def chat_endpoint(chat_request: ChatRequest):
    user_message = chat_request.message
    session_id = chat_request.session_id
    
    bot_response_obj = get_response(user_message, session_id)
    
    # Log to database
    log_chat(user_message, bot_response_obj["text"], session_id)
    
    return bot_response_obj
    
@app.get("/history", response_class=HTMLResponse)
async def view_history(request: Request):
    logs = get_all_logs()
    return templates.TemplateResponse(
        request=request, name="history.html", context={"logs": logs}
    )

@app.post("/clear-history")
async def clear_history():
    clear_all_logs()
    return {"message": "History cleared successfully"}

# Admin Routes
@app.get("/admin", response_class=HTMLResponse)
async def admin_page(request: Request):
    faqs = get_all_faqs()
    return templates.TemplateResponse(
        request=request, name="admin.html", context={"faqs": faqs}
    )

@app.post("/admin/faqs")
async def create_faq(question: str = Form(...), answer: str = Form(...)):
    add_faq(question, answer)
    return {"message": "FAQ added"}

@app.post("/admin/faqs/delete/{faq_id}")
async def remove_faq(faq_id: int):
    delete_faq(faq_id)
    return {"message": "FAQ deleted"}


if __name__ == "__main__":
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=True)
